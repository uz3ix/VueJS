<template>
  <div class="palette-wrapper">
    <div
      v-for="(color, index) in colors"
      :key="index"
      class="color-item"
      :style="{ backgroundColor: color }"
    >
      <div class="color-info">
        <span>{{ color }}</span>
        <button class="lock-btn" @click="$emit('toggle-lock', index)">
          <span v-if="lockedColors[index]">🔒</span>
          <span v-else>🔓</span>
        </button>
      </div>
    </div>
  </div>
</template>

<script setup>
defineProps({
  colors: {
    type: Array,
    required: true
  },
  lockedColors: {
    type: Array,
    required: true
  }
});
</script>

<style scoped>
.palette-wrapper {
  display: flex;
  gap: 10px;
  margin-top: 20px;
}

.color-item {
  width: 100px;
  height: 120px;
  border-radius: 8px;
  position: relative;
  display: flex;
  align-items: flex-end;
  justify-content: center;
  color: white;
  font-weight: bold;
  padding: 8px;
}

.color-info {
  width: 100%;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.lock-btn {
  background: rgba(0,0,0,0.25);
  border: none;
  border-radius: 4px;
  cursor: pointer;
  color: white;
  padding: 3px 6px;
}
</style>
