<template>
  <div id="app">
    <nav class="navbar">
      <router-link to="/">Генератор</router-link>
      <router-link to="/custom">Моя палитра</router-link>
      <router-link to="/export">Импорт / Экспорт</router-link>
    </nav>

    <router-view />
  </div>
</template>

<style>
.navbar {
  display: flex;
  gap: 20px;
  padding: 15px;
  border-bottom: 1px solid #ddd;
}
</style>
