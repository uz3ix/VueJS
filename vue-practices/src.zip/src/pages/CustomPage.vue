<template>
  <div class="custom-page">
    <h1>Палитра по базовому цвету</h1>

    <input type="color" v-model="baseColor" />

    <button @click="generateFromBase">Сгенерировать</button>

    <ColorPalette
      :colors="colors"
      :lockedColors="lockedColors"
      @toggle-lock="toggleLock"
    />
  </div>
</template>

<script setup>
import { ref } from "vue";
import ColorPalette from "../components/ColorPalette.vue";
import { usePaletteStore } from "../store/paletteStore.js";

const paletteStore = usePaletteStore();

const baseColor = ref("#ff0000");
const colors = ref([]);
const lockedColors = ref([]);

function shade(col, percent) {
  let R = parseInt(col.substring(1, 3), 16);
  let G = parseInt(col.substring(3, 5), 16);
  let B = parseInt(col.substring(5, 7), 16);

  R = parseInt((R * (100 + percent)) / 100);
  G = parseInt((G * (100 + percent)) / 100);
  B = parseInt((B * (100 + percent)) / 100);

  return (
    "#" +
    (R < 255 ? R : 255).toString(16).padStart(2, "0") +
    (G < 255 ? G : 255).toString(16).padStart(2, "0") +
    (B < 255 ? B : 255).toString(16).padStart(2, "0")
  );
}

function generateFromBase() {
  colors.value = [
    shade(baseColor.value, -40),
    shade(baseColor.value, -20),
    baseColor.value,
    shade(baseColor.value, 20),
    shade(baseColor.value, 40)
  ];

  lockedColors.value = [false, false, false, false, false];

  paletteStore.setPalette(colors.value, lockedColors.value);
}

function toggleLock(index) {
  lockedColors.value[index] = !lockedColors.value[index];
  paletteStore.setPalette(colors.value, lockedColors.value);
}
</script>

<style scoped>
.custom-page {
  padding: 20px;
}
</style>
